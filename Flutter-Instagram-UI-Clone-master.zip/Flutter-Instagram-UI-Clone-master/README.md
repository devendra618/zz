# flutter_instagram_ui_clone

### Some Screenshots

<img src="ss_android.jpg" height="300em" />

<img src="ss_ios.png" height="300em" />

A new Flutter project.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
